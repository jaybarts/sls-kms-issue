This project is a sample that attempts to reproduce an issue that was raised for the serverless project.  See the following link:
https://github.com/serverless/examples/issues/279#issuecomment-444672189

The issue seems to be related to a serverless deployment that does not seem to fully deploy successfully due to some error. In the case of this project, we want to purposely cause the serverless deployment to fail on the first try.  This is achieved by configuring a cloudwatch scheduled event rule for a lambda function that uses a name that is already in use (causing an error). From the serverless.yml: 

```yaml
    loader: 
        timeout: 300
        handler: shared/handler.initialize
        events: 
            - schedule: 
                name: ExistingRule
                rate: cron(0 1 * * ? *)
                enabled: true
```

## Steps to reproduce

1. Execute deployment with stage: ```sls deploy --stage test```  <br>The deployment will fail and the serverless cf stack will eventually get into the update rollback complete state after successfully rolling back the deployment.  The serverless error will look as follows:   

```
Serverless Error ---------------------------------------
 
  An error occurred: LoaderEventsRuleSchedule1 - ExistingRule already exists.
```

2. Correct the event rule name for the loader lambda in the serverless.yml to something unique:

```yaml
            - schedule: 
                name: ExistingRule-new
                rate: cron(0 1 * * ? *)
                enabled: true
```

3. Redeploy:  ```sls deploy --stage test```
